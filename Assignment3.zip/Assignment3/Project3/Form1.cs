﻿/*
 * Jeff Koss
 * Date: 04/09/23
 * Class: MS539 Programming Concepts
 * Professor: Jill Coddington
 * Assignment: Project 3
 * ETA: 1 hour
 */

/*
 * This project took me over 4 hours due to research,
 * finding the right pictures,
 * and code testing. It took me
 * way more time than I thought.
 */





using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;


namespace Project3
{
    public partial class Form1 : Form
    {
        int launchTime;
        int safeLand;
        public Form1()
        {
            InitializeComponent();
        }

        private void LaunchError()
        {
            MessageBox.Show("Please enter a number from 10 to 100");
 
        }

        private void LaunchSuccess()
        {
            MessageBox.Show("Launch Sequence Started!");
        }

        private void LaunchSequence()
        {
            for (int i = launchTime; i > 0; i--)
            {
                String launchTimer = launchTime.ToString();
                MessageBox.Show(launchTimer);
                launchTime --;
            }
            SuccessRate();
        }

        private void SuccessRate()
        {
            Random rand = new Random();
            safeLand = rand.Next(2);
            LandSafe();
        }

        private void LandSafe()
        {
            if (safeLand == 0)
            {
                pictureBox2.Visible = true;
                pictureBox1.Visible = false;
                label3.Text = ("You have crashed!");
                label3.Visible = true;
            }
            else
            {
                pictureBox2.Visible = false;
                pictureBox1.Visible = true;
                label3.Text = ("You have launched!");
                label3.Visible = true;
            }
        }

        private void RocketSchool()
        {
            try
            {
                launchTime = int.Parse(textBox2.Text);
            }
            catch
            {
                MessageBox.Show("You must type in a number, try again!");
            }

            if (launchTime < 10 || launchTime > 100)
            {
                LaunchError();

            }
            else
            {
                LaunchSuccess();
                LaunchSequence();
            }
        }
        private void LogFile()
        {
          StreamWriter outputFile;
          outputFile = File.CreateText("missions.txt");
          outputFile.WriteLine(textBox2.Text);
          if (safeLand == 0)
           {
            outputFile.WriteLine("Crashed");
           }
           else if (safeLand == 1)
            {
             outputFile.WriteLine("Launched");
            }
            else
            {
             outputFile.WriteLine("Error");
            }
            outputFile.Close();

            
        }
            


    private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            pictureBox1.Visible = false;
            label3.Visible = false;
            RocketSchool();
            LogFile();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
